IF DB_ID(N'Blood_Connect') IS NULL
BEGIN
    CREATE DATABASE [Blood_Connect];
END;
GO

USE [Blood_Connect];
GO

IF OBJECT_ID(N'dbo.blood_units', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.blood_units
    (
        id varchar(36) NOT NULL CONSTRAINT pk_blood_units PRIMARY KEY,
        blood_group varchar(5) NOT NULL,
        component varchar(30) NOT NULL CONSTRAINT df_blood_units_component DEFAULT N'Whole Blood',
        branch nvarchar(255) NOT NULL CONSTRAINT df_blood_units_branch DEFAULT N'Main Blood Bank',
        status varchar(30) NOT NULL CONSTRAINT df_blood_units_status DEFAULT N'Pending Screening',
        collected_at datetime2 NULL,
        expires_at datetime2 NOT NULL,
        hiv_non_reactive bit NULL,
        hepatitis_bnon_reactive bit NULL,
        hepatitis_cnon_reactive bit NULL,
        syphilis_non_reactive bit NULL,
        malaria_non_reactive bit NULL,
        cross_match_compatible bit NULL,
        quality_notes nvarchar(max) NULL,
        screened_at datetime2 NULL
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_blood_units_status' AND object_id = OBJECT_ID(N'dbo.blood_units'))
    CREATE INDEX ix_blood_units_status ON dbo.blood_units(status);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_blood_units_group_component' AND object_id = OBJECT_ID(N'dbo.blood_units'))
    CREATE INDEX ix_blood_units_group_component ON dbo.blood_units(blood_group, component);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_blood_units_expires_at' AND object_id = OBJECT_ID(N'dbo.blood_units'))
    CREATE INDEX ix_blood_units_expires_at ON dbo.blood_units(expires_at);
GO
